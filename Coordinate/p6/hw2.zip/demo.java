public class demo{
    public static void main(String[]args){
	coordinate a,b,c;
	a = new coordinate();
	b = new coordinate(3,5);
	c = b;
	System.out.println("blah:"+a.toString());
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);

	
    }

}
